import javolution.io.Union;
import javolution.io;
import java.lang.Object;
import java.io.Union;
import java.javolution.io;



public class Change_Type extends Union
{

	char AsChar[];
	
	
	 Signed32   asInt    = new Signed32();
     Float32    asFloat  = new Float32();
     Utf8String asString = new Utf8String(12);
     
     
 	
	
}
